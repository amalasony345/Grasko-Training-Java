package pac;

public class UnderGraduate extends Degree{
	void getDegree() {
		System.out.println("I am an undergraduate");
	}

	public static void main(String[] args) {
		UnderGraduate u=new UnderGraduate();
		u.getDegree();
	}

}
