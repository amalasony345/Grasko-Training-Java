package pac;

public class BankB extends Bank{
	int getBalance() {
		return 1500;
	}
	public static void main(String[] args) {
		BankB b=new BankB();
		int balance1=b.getBalance();
		System.out.println(balance1);
	}

}


