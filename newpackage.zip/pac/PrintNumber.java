package pac;

public class PrintNumber {
	void printn(int i) {
		
		System.out.println("integer value is"+i);
	}
	void printn(Double d) {
		
		System.out.println("the double value is"+d);
	}


	public static void main(String[] args) {
		PrintNumber p=new PrintNumber();
	
		p.printn(10);
		p.printn(2.3);
	}

}
