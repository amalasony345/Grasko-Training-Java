package pac;

public class Student {
	String name;
	int age;
	String address;

	public Student(String name,int age) {
		this.name=name;
		this.age=age;
		
	}
	public Student(String name,int age,String address) {
		this.name=name;
		this.age=age;
		this.address=address;
	}

	
	public String toString() {
		return this.name+" "+this.age+" "+this.address;
	}
	public static void main(String[] args) {
		Student s1=new Student("unknown",0,"not available");
		Student s2=new Student("setInfo",1,"j");
		Student s3=new Student("setInfo",2,"k");
		Student s4=new Student("c",3);
		Student s5=new Student("d",4);
		Student s6=new Student("e",5,"n");
		Student s7=new Student("f",6,"o");
		Student s8=new Student("g",7,"p");
		Student s9=new Student("h",8,"q");
		Student s10=new Student("i",9,"r");
		System.out.println(s1.toString());
		System.out.println(s2.toString());
		System.out.println(s3.toString());
		System.out.println(s4.toString());
		System.out.println(s5.toString());
		System.out.println(s6.toString());
		System.out.println(s7.toString());
		System.out.println(s8.toString());
		System.out.println(s9.toString());
		System.out.println(s10.toString());
		Student stu[]= {s1,s2,s3,s4,s5,s6,s7,s8,s9,s10};
		for(int i=0;i<=stu.length-1;i++) {
			System.out.println(stu[i]);
		}
	}
}
