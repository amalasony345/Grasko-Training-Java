package pac;

public class Degree {
	void getDegree() {
		System.out.println("I got a degree");
	}
	public static void main(String[] args) {
		Degree d=new Degree();
		d.getDegree();
	}
}
