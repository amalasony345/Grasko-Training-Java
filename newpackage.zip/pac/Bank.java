package pac;

public class Bank {
	int getBalance() {
		return 0;
	}
}
