package newpackage;

public class StudentA extends Marks{
	void getMarks() {
		Double Maths=56.0, Eng=87.0, CS=67.0;
		Double total=100.0;
		Double perc1=(Maths/total)*100;
		Double perc2=(Eng/total)*100;
		Double perc3=(CS/total)*100;
		Double tot_perc=(perc1+perc2+perc3)/3;
		System.out.println("percentge of sub1 is:"+perc1);
		System.out.println("percentge of sub2 is:"+perc2);
		System.out.println("percentge of sub3 is:"+perc3);
		System.out.println("percentge of student A is:"+tot_perc);
		
		
	}
	public static void main(String[] args) {
		StudentA s=new StudentA();
		s.getMarks();
	}

}
