package newpackage;

public abstract class Shape {
	
	void Square_area(Double l){
		
	}
	void Circle_area(Double r){
		
	}
	void Rectangle_area(Double l1,Double b){
		
	}
	void Triangle_area(double b,double h) {
		
		
	}
}
