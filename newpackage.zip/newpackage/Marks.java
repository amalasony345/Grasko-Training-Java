package newpackage;

public abstract class Marks {
	void getMarks() {
		
	}
}
