package newpackage;

import java.util.Scanner;

public class Multiply {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the numbers");
		int a=sc.nextInt();
		int b=sc.nextInt();
		int mult=a*b;
		System.out.println("multiplication of the 2 numbers is "+ mult);	
	}

}
