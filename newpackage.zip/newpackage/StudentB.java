package newpackage;

public class StudentB extends Marks{

	void getMarks() {
		Double sub1=45.0,sub2=57.0,sub3=97.0,sub4=98.0;
		Double total=100.0;
		Double perc1=(sub1/total)*100;
		Double perc2=(sub2/total)*100;
		Double perc3=(sub3/total)*100;
		Double perc4=(sub4/total)*100;
		Double tot_perc=(perc1+perc2+perc3+perc4)/4;
		System.out.println("percentge of sub1 is:"+perc1);
		System.out.println("percentge of sub2 is:"+perc2);
		System.out.println("percentge of sub3 is:"+perc3);
		System.out.println("percentge of sub4 is:"+perc4);
		System.out.println("percentge of student B is:"+tot_perc);
		
		
	}
	public static void main(String[] args) {
		StudentB s1=new StudentB();
		s1.getMarks();
	}

}


