package newpackage;

import java.util.Scanner;

public class Ascii {

	public static void main(String[] args) {
		
		char c='A';
		int ascii=c;
		System.out.println("ascii value for "+c+"is "+ascii);
		
		
		

	}

}
