package newpackage;

public class Triangle extends Shape{
	private double h=2.3;
	private double b=4.5;
	public void Triangle_area(){
		
		Double Triangle_area=0.5*b*h;
		System.out.println("area of the triangle:"+Triangle_area);
		
		
	}
	public static void main(String[] args) {
		
		
	
		Triangle s=new Triangle();
		s.Triangle_area();
		
		
	}

}

