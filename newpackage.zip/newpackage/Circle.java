package newpackage;

public class Circle extends Shape {
	void Circle_area(Double r){
		Double circle_area=3.14*r*r;
		System.out.println("area of the circle:"+circle_area);
		
	}
	public static void main(String[] args) {
		Shape s=new Circle();
		Circle c=new Circle();
		s.Circle_area(3.2);
	}

}
