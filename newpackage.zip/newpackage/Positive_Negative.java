package newpackage;

import java.util.Scanner;

public class Positive_Negative {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the number");
		int n=sc.nextInt();
		if(n<0)
		{
			System.out.println(n+" is a negative number");
			
		}
		else
			System.out.println(n+" is a positive number");
	}

}
