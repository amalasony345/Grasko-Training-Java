package newpackage;

import java.util.Scanner;

public class Clock {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the hour, minutes,and seconds");
		int hr=sc.nextInt();
		int mnt=sc.nextInt();
		int sec=sc.nextInt();
		if(hr>=24||hr<0||mnt>60||mnt<0||sec<0||sec>60)
		{
			System.out.println("the time is invalid");
			
		}
		else {
			
		if(hr<12)
		{
			System.out.println("the time is "+hr+":"+mnt+":"+sec+"AM");
			
				
		}
		else if(hr>=12)
		{
			System.out.println("the time is "+hr+":"+mnt+":"+sec+"PM");
		}
		}
	}

}
