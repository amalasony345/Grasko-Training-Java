package newpackage;

import java.util.Scanner;

public class Readnumber {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the number");
		int n=sc.nextInt();
		System.out.println("user entered number is "+n);
	}

}
