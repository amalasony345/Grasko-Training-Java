package newpackage;

public class Square extends Shape {
	void Square_area(Double l){
		Double square_area=l*l;
		System.out.println("area of the square:"+square_area);
		
		
	}
	public static void main(String[] args) {
		
		
	
		Square s=new Square();
		s.Square_area(5.2);
		
	}

}
