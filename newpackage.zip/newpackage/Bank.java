package newpackage;

import java.util.Scanner;

public class Bank {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the deposit");
		int dep=sc.nextInt();
		System.out.println("enter the withdraw");
		int wd=sc.nextInt();
		int bal=dep-wd;
		
		if(wd>bal)
		{
			System.out.println("sorry you can't withdraw money from your account");
		}
		
	}

}
