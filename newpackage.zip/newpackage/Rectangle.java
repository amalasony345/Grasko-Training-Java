package newpackage;

public class Rectangle extends Shape {
	void Rectangle_area(Double l1,Double b){
		Double rectangle_area=l1*b;
		System.out.println("area of the rectangle:"+rectangle_area);
		
	}
	public static void main(String[] args) {
		Rectangle r=new Rectangle();
		r.Rectangle_area(3.4,5.0);

	}

}
