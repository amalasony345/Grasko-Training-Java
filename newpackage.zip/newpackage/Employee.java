package newpackage;

import java.util.Scanner;

public class Employee {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the salary of the employee");
		int sal=sc.nextInt();
		int tax=0;
		if(sal<=50000)
		{
			System.out.println("tax is "+ tax);
		}
		else if(sal>50000 && sal<=60000)
		{
			tax=tax+(sal-50000)*10/100;
			System.out.println("tax is "+ tax);
		}
		else if(sal>60000 && sal<=150000)
		{
			tax=tax+((sal-60000)*20/100)+100;
			System.out.println("tax is "+ tax);
		}
		else
		{
			tax=tax+((sal-150000)*30/100)+(90000*20/100)+100;
			System.out.println("tax is "+ tax);
		}
		
	}

}
