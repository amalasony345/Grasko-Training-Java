
public abstract class Bank {
	void getBalance() {
		
	}
}
