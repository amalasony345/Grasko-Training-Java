
public class MyClass {

	public static void main(String[] args) {
		int i,j,sum,sub,prod,div;
		i=60;
		j=20;
		sum=i+j;
		sub=i-j;
		prod=i*j;
		div=i/j;
		System.out.println("sum="+sum);
		System.out.println("difference="+sub);
		System.out.println("product="+prod);
		System.out.println("division="+div);
		
		
		
	}

}
