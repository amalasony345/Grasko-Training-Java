
public class Bank_B extends Bank {
	void getBalance() {
		int deposit=150;
		int withdraw=170;
		int balance=deposit-withdraw;
		System.out.println("balance in the account is "+balance+"Rs");
		if(withdraw>balance) {
			System.out.println("sorry!!insufficient balance");
		}
		else {
			System.out.println(withdraw+"Rs has withdrawen from your account");
		}
	}
	public static void main(String[] args) {
		Bank_B b1=new Bank_B();
		b1.getBalance();

	}

}
