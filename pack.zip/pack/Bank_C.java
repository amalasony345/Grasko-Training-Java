
public class Bank_C extends Bank{
	void getBalance() {
		int deposit=200;
		int withdraw=100;
		int balance=deposit-withdraw;
		System.out.println("balance in the account is "+balance+"Rs");
		if(withdraw>balance) {
			System.out.println("sorry!!insufficient balance");
		}
		else {
			System.out.println(withdraw+"Rs has withdrawen from your account");
		}
	}
	public static void main(String[] args) {
		Bank_C b2=new Bank_C();
		b2.getBalance();
	}

}
