
public class Bank_A extends Bank{
	void getBalance() {
		int deposit=100;
		int withdraw=20;
		int balance=deposit-withdraw;
		System.out.println("balance in the account is "+balance+"Rs");
		if(withdraw>balance) {
			System.out.println("sorry!!insufficient balance");
		}
		else {
			System.out.println(withdraw+"Rs has withdrawen from your account");
		}
	}
	public static void main(String[] args) {
		Bank_A b=new Bank_A();
		b.getBalance();
	}

}
