package pac;

public class NewClass {
	void printn(char c,int n) {
		System.out.println(c+","+n);
	}
	void printn(int n,char c) {
		System.out.println(n+","+c);
	}
	public static void main(String[] args) {
		NewClass nc=new NewClass();
		nc.printn('a', 11);
		nc.printn(3, 'd');
		
	}

}
