package pac;

public class PostGraduate extends Degree {

	void getDegree() {
		System.out.println("I am a postgraduate");
	}

	public static void main(String[] args) {
		PostGraduate p=new PostGraduate();
		p.getDegree();
	}

}