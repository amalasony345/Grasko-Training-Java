package pac;

public class Area {
	void area(double length) {
		double area=length*length;
		System.out.println("area of the square is:"+area);
	}
	void area(double length,double breadth) {
		double area=length*breadth;
		System.out.println("area of the rectangle is :"+area);
	}

	public static void main(String[] args) {
		Area a=new Area();
		a.area(4);
		a.area(2.0, 6.2);
	}

}
