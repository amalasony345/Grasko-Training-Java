package pac;

public class BankC extends Bank {
	int getBalance() {
		return 2000;
	}
	public static void main(String[] args) {
		BankC b=new BankC();
		int balance2=b.getBalance();
		System.out.println(balance2);
	}

}



