package pac;

public class BankA extends Bank{
	int getBalance() {
		return 1000;
	}
	public static void main(String[] args) {
		BankA b=new BankA();
		int balance=b.getBalance();
		System.out.println(balance);
	}

}
