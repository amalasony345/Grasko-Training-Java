package collection;
import java.util.*;
public class IteratePosition {
	public static void main(String[] args) {
		LinkedList <String> lst=new LinkedList <String>();
		lst.add("violet");
		lst.add("indigo");
		lst.add("blue");
		lst.add("green");
		lst.add("yellow");
		lst.add("orange");
		lst.add("red");
		for(int i=4;i<lst.size();i++)
		{
			System.out.println(lst.get(i));
		}
	}
}
