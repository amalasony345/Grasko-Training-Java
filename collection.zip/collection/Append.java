package collection;
import java.util.*;
public class Append {
	public static void main(String[] args) {
		
		
		LinkedList <String> lst=new LinkedList <String>();
		lst.add("violet");
		lst.add("indigo");
		lst.add("blue");
		lst.add("green");
		lst.add("yellow");
		
		
		System.out.println(lst);
		}
}
