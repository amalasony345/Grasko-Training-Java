package collection;
import java.util.*;
public class ArrayListEmptyOrNot {
	public static void main(String[] args) {
		ArrayList <String> list=new ArrayList <String>();
		list.add("violet");
		list.add("indigo");
		list.add("blue");
		list.add("green");
		list.add("yellow");
		list.add("orange");
		list.add("red");
		Iterator itr=list.iterator();
		while(itr.hasNext()) {
			System.out.println(itr.next());
		}
		
		System.out.println(list.isEmpty());
	}
}
