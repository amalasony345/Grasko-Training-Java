package collection;
import java.util.*;
public class LLInsertFirstLast {
	public static void main(String[] args) {
		
	
	LinkedList <String> lst=new LinkedList <String>();
	lst.add("violet");
	lst.add("indigo");
	lst.add("blue");
	lst.add("green");
	lst.add("yellow");
	lst.add("orange");
	lst.add("red");
	Iterator it=lst.iterator();
	while(it.hasNext()) {
		System.out.println(it.next());
	}
	lst.addFirst("purple");
	lst.addLast("Pink");
	System.out.println(lst);
	}

}
