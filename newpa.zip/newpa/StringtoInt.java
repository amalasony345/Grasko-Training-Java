package newpa;
import java.util.Scanner;
public class StringtoInt {
	public static void main(String[] args) {
		try {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the string");
		String s=sc.next();
		int i=Integer.parseInt(s);
		System.out.println(i);
		}catch(NumberFormatException e) {
			System.out.println(e);
		}
	}
}
