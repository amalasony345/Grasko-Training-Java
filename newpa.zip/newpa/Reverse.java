package newpa;
import java.util.Scanner;
public class Reverse {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the String");
		String str=sc.nextLine();
		char ch[]=str.toCharArray();
		String rs=" ";
		for(int i=ch.length-1;i>=0;i--) {
			int j=i;
			while(i>=ch.length) {
				i++;
			}
			int k=i-1;
			while(k>=j) {
				rs=rs+ch[k];
				k--;
			}
			if(i<ch.length)
				rs=rs+ch[i];
			
		}
		System.out.println(rs);
		

	}

}

