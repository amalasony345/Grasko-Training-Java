package newpa;
import java.util.Scanner;
public class SameRightdigit {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the 3 integers:");
		int a=sc.nextInt();
		int b=sc.nextInt();
		int c=sc.nextInt();
		int r1=a%10;
		int r2=b%10;
		int r3=c%10;
		if(r1==r2&&r2==r3) {
			System.out.println("true");
		}
		else if(r1==r2||r1==r3||r2==r3)
		{
			System.out.println("true");
		}
		else
			System.out.println("false");
	}

}
