package newpa;
import java.util.Scanner;
public class SecToHrMtSec {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the seconds");
		int sec=sc.nextInt();
		int hour=sec/3600;
		int min=sec/60;
		
			
			System.out.println("Minute is:"+min);
			System.out.println("Hour is:"+hour);
			System.out.println("seconds are:"+sec);
			
			
		}
		
		
	}
